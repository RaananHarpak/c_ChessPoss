

#ifndef TESTS_H_
#define TESTS_H_
#define _CRT_SECURE_NO_WARNINGS


void TestQuestion4();

void TestQuestion5();


#endif /* TESTS_H_ */
